void printIntArray(int array[], int size);
int compactar(int array[], int size, int indice);
int calcularIndiceMinimo(int array[], int size);

void nadiaSort(int array[], int size,int arrayOrdenado[]);
void nadiaSort2(int array[], int size);
void insertionSort(int array[], int size);
void bubleSort(int array[], int size);
void bubleSort2(int array[], int size);
void quickSort(int array[], int size);
void selectionSort(int array[], int size);

int fillFromFile(int array[], int maxSize);

