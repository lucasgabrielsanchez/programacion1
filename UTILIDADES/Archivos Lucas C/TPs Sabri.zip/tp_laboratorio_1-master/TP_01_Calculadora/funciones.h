float suma(float a,float b);
float resta(float a,float b);
float multiplicacion(float a,float b);
float division(float a,float b);
int factorial(int a);
int Options(char menu[], char error[], int desde, int hasta);
//float validarNumero(float numero);

