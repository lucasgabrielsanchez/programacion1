#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

int suma(int a, int b);

int resta(int a, int b);

int multip(int a, int b);

int division(int a, int b);

int valOpMen(char error[], int desde, int hasta);

int factorial(int a);


#endif // FUNCIONES_H_INCLUDED
